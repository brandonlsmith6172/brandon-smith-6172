﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



namespace ConsoleApp2
    {
        class Program
        {
            static void Main(string[] args)
            {

           // //PLEASE COMMENT OUT EACH BLOCK OF CODE IDENTIFIED BY THE FORWARD SLASHES
           //// sum of numbers
           // double firstNum, secondNum, thirdNum, fourthNum, fifthNum, sixthNum, seventhNum, eighthNum, ninethNum, tenthNum, sum;
           // Console.WriteLine("Please input a number between 0 and 100: ");
           // firstNum = double.Parse(Console.ReadLine());
           // Console.WriteLine("Please input another number between 0 and 100: ");
           // secondNum = double.Parse(Console.ReadLine());
           // Console.WriteLine("Please input another number between 0 and 100: ");
           // thirdNum = double.Parse(Console.ReadLine());
           // Console.WriteLine("Please input another number between 0 and 100: ");
           // fourthNum = double.Parse(Console.ReadLine());
           // Console.WriteLine("Please input another number between 0 and 100: ");
           // fifthNum = double.Parse(Console.ReadLine());
           // Console.WriteLine("Please input another number between 0 and 100: ");
           // sixthNum = double.Parse(Console.ReadLine());
           // Console.WriteLine("Please input another number between 0 and 100: ");
           // seventhNum = double.Parse(Console.ReadLine());
           // Console.WriteLine("Please input another number between 0 and 100: ");
           // eighthNum = double.Parse(Console.ReadLine());
           // Console.WriteLine("Please input another number between 0 and 100: ");
           // ninethNum = double.Parse(Console.ReadLine());
           // Console.WriteLine("Please input another number between 0 and 100: ");
           // tenthNum = double.Parse(Console.ReadLine());
           // Console.WriteLine("Please input another number between 0 and 100: ");
           // sum = firstNum + secondNum + thirdNum + fourthNum + fifthNum + sixthNum + seventhNum + eighthNum + ninethNum + tenthNum;
           // Console.WriteLine("The sum of your numbers are {sum}");
           // //


           // //Average ten scores
           // double firstNum, secondNum, thirdNum, fourthNum, fifthNum, sixthNum, seventhNum, eighthNum, ninethNum, tenthNum, sum, average;
           // int testNumber = 10;
           // while (testNumber > 0)
           // {
           //     Console.WriteLine("Please input a number between 0 and 100: ");
           //     firstNum = firstNum + double.Parse(Console.ReadLine());
           //     testNumber--;
           // }

           // Console.WriteLine("Please input a number between 0 and 100: ");
           // firstNum = double.Parse(Console.ReadLine());
           // Console.WriteLine("Please input another number between 0 and 100: ");
           // secondNum = double.Parse(Console.ReadLine());
           // Console.WriteLine("Please input another number between 0 and 100: ");
           // thirdNum = double.Parse(Console.ReadLine());
           // Console.WriteLine("Please input another number between 0 and 100: ");
           // fourthNum = double.Parse(Console.ReadLine());
           // Console.WriteLine("Please input another number between 0 and 100: ");
           // fifthNum = double.Parse(Console.ReadLine());
           // Console.WriteLine("Please input another number between 0 and 100: ");
           // sixthNum = double.Parse(Console.ReadLine());
           // Console.WriteLine("Please input another number between 0 and 100: ");
           // seventhNum = double.Parse(Console.ReadLine());
           // Console.WriteLine("Please input another number between 0 and 100: ");
           // eighthNum = double.Parse(Console.ReadLine());
           // Console.WriteLine("Please input another number between 0 and 100: ");
           // ninethNum = double.Parse(Console.ReadLine());
           // Console.WriteLine("Please input another number between 0 and 100: ");
           // tenthNum = double.Parse(Console.ReadLine());
           // Console.WriteLine("Please input another number between 0 and 100: ");
           // sum = firstNum + secondNum + thirdNum + fourthNum + fifthNum + sixthNum + seventhNum + eighthNum + ninethNum + tenthNum;
           // average = sum / 10;
           // if (average >= 97)
           // {
           //     Console.WriteLine("Your letter grade is an A+");
           // }
           // else if (average >= 93)
           // {
           //     Console.WriteLine("Your letter grade is an A");
           // }

           // else if (average >= 90)
           // {
           //     Console.WriteLine("Your letter grade is an A-");
           // }
           // else if (average >= 87)
           // {
           //     Console.WriteLine("Your letter grade is an B+");
           // }
           // else if (average >= 83)
           // {
           //     Console.WriteLine("Your letter grade is an B");
           // }
           // else if (average >= 80)
           // {
           //     Console.WriteLine("Your letter grade is an B-");
           // }

           // else if (average >= 77)
           // {
           //     Console.WriteLine("Your letter grade is an C+");
           // }
           // else if (average >= 73)
           // {
           //     Console.WriteLine("Your letter grade is an C");
           // }
           // else if (average >= 70)
           // {
           //     Console.WriteLine("Your letter grade is an C-");
           // }
           // else if (average >= 67)
           // {
           //     Console.WriteLine("Your letter grade is an D+");
           // }
           // else if (average >= 63)
           // {
           //     Console.WriteLine("Your letter grade is an D");
           // }
           // else if (average >= 60)
           // {
           //     Console.WriteLine("Your letter grade is an D-");
           // }
           // else if (average <= 59)
           // {
           //     Console.WriteLine("Your letter grade is an F");
           //     int testScore = 0, testAverage = 0, testDec = 0;

           //     //

           //     //enter test number
           //     Console.Write("Please input the number of test scores you want calculated: ");
           //     int testNumber = Convert.ToInt32(Console.ReadLine());
           //     testDec = testNumber;

           //     while (testDec > 0)
           //     {
           //         Console.Write("Enter test score: ");
           //         testScore = testScore + Convert.ToInt32(Console.ReadLine());
           //         testAverage = testScore / testNumber;
           //         testDec--;

           //         if (testDec == 0)
           //         {
           //             if (testAverage >= 97)
           //             {
           //                 Console.Write($"Your letter grade is an A+ and your score is {testAverage}.");
           //             }
           //             else if (testAverage >= 93)
           //             {
           //                 Console.Write($"Your letter grade is an A and your score is {testAverage}.");
           //             }
           //             else if (testAverage >= 90)
           //             {
           //                 Console.Write($"Your letter grade is an A- and your score is {testAverage}.");
           //             }
           //             else if (testAverage >= 87)
           //             {
           //                 Console.Write($"Your letter grade is an B+ and your score is {testAverage}.");
           //             }
           //             else if (testAverage >= 83)
           //             {
           //                 Console.Write($"Your letter grade is an B and your score is {testAverage}.");
           //             }
           //             else if (testAverage >= 80)
           //             {
           //                 Console.Write($"Your letter grade is an B- and your score is {testAverage}.");
           //             }
           //             else if (testAverage >= 77)
           //             {
           //                 Console.Write($"Your letter grade is an C+ and your score is {testAverage}.");
           //             }
           //             else if (testAverage >= 73)
           //             {
           //                 Console.Write($"Your letter grade is an C and your score is {testAverage}.");
           //             }
           //             else if (testAverage >= 70)
           //             {
           //                 Console.Write($"Your letter grade is an C- and your score is {testAverage}.");
           //             }
           //             else if (testAverage >= 67)
           //             {
           //                 Console.Write($"Your letter grade is an D+ and your score is {testAverage}.");
           //             }
           //             else if (testAverage >= 63)
           //             {
           //                 Console.Write($"Your letter grade is an D and your score is {testAverage}.");
           //             }
           //             else if (testAverage >= 60)
           //             {
           //                 Console.Write($"Your letter grade is an D- and your score is {testAverage}.");
           //             }
           //             else if (testAverage <= 59)
           //             {
           //                 Console.WriteLine($"Your letter grade is an F and your score is {testAverage}.");
           //             }

           //             //

           //             // while  with an if statement with done parameter
                        int testSum = 0, testAverage = 0, testDec = 0;
            string testString;
            Console.WriteLine("Please input each test score and hit [ENTER]. Whenever you are finished, please type the word 'done'.");
            while (testDec >= 0)
            {
                testString = (Console.ReadLine());

                if (testString == "done" || testString == "DONE" || testString == "Done")
                {
                    testAverage = testSum / testDec;
                    if (testAverage >= 97)
                    {
                        Console.Write($"Your letter grade is an A+ and your score is {testAverage}.");
                        goto finishCode;
                    }
                    else if (testAverage >= 93)
                    {
                        Console.Write($"Your letter grade is an A and your score is {testAverage}.");
                        goto finishCode;
                    }
                    else if (testAverage >= 90)
                    {
                        Console.Write($"Your letter grade is an A- and your score is {testAverage}.");
                        goto finishCode;
                    }
                    else if (testAverage >= 87)
                    {
                        Console.Write($"Your letter grade is an B+ and your score is {testAverage}.");
                        goto finishCode;
                    }
                    else if (testAverage >= 83)
                    {
                        Console.Write($"Your letter grade is an B and your score is {testAverage}.");
                        goto finishCode;
                    }
                    else if (testAverage >= 80)
                    {
                        Console.Write($"Your letter grade is an B- and your score is {testAverage}.");
                        goto finishCode;
                    }
                    else if (testAverage >= 77)
                    {
                        Console.Write($"Your letter grade is an C+ and your score is {testAverage}.");
                        goto finishCode;
                    }
                    else if (testAverage >= 73)
                    {
                        Console.Write($"Your letter grade is an C and your score is {testAverage}.");
                        goto finishCode;
                    }
                    else if (testAverage >= 70)
                    {
                        Console.Write($"Your letter grade is an C- and your score is {testAverage}.");
                        goto finishCode;
                    }
                    else if (testAverage >= 67)
                    {
                        Console.Write($"Your letter grade is an D+ and your score is {testAverage}.");
                        goto finishCode;
                    }
                    else if (testAverage >= 63)
                    {
                        Console.Write($"Your letter grade is an D and your score is {testAverage}.");
                        goto finishCode;
                    }
                    else if (testAverage >= 60)
                    {
                        Console.Write($"Your letter grade is an D- and your score is {testAverage}.");
                        goto finishCode;
                    }
                    else if (testAverage <= 59)
                    {
                        Console.WriteLine($"Your letter grade is an F and your score is {testAverage}.");
                        goto finishCode;
                    }
                }
                else if (Convert.ToInt32(testString) >= 0 && Convert.ToInt32(testString) <= 100)
                {
                    testSum = testSum + Convert.ToInt32(testString);
                    testDec++;
                }
                else
                {
                    Console.WriteLine("Please enter a Number between 1 and 100.");
                }
            }
                finishCode:
                Console.ReadLine();              
            }
            }
        }
    




    

