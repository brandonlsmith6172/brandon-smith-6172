﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EX_1A_c_sharp
{
    class Program
    {
        static void Main(string[] args)
        {
            
            //Area and Circumference of a circle

            Console.Write("Enter an integer for the radius of a circle: ");
            double circleRadius = Double.Parse(Console.ReadLine());
            double circleCircumference = 2 * Math.PI * circleRadius;
            double circleArea = Math.PI * (circleRadius * circleRadius);
            Console.WriteLine($"The circumerefence of the circle is: {circleCircumference}");
            Console.WriteLine($"The area of the circle is: {circleArea}");
            Console.WriteLine("Press enter to continue.");
            Console.ReadLine();

            //Volume of a hemisphere

            Console.Write("Enter an integer for the radius of a hemisphere: ");
            double hemisphereRadius = Double.Parse(Console.ReadLine());
            double hemisphereDivide = 1.3333333;
            double hemisphereRadiusPower = Math.Pow(hemisphereRadius, 3);
            double hemisphereVolume = (hemisphereDivide * Math.PI * (hemisphereRadiusPower)) / 2;
            Console.WriteLine($"The volume of the hemisphere is: {hemisphereVolume}");
            Console.WriteLine("Press enter to continue.");
            Console.ReadLine();

            //Area of a triangle given the lengths of the sides

            Console.Write("Enter an integer for the length of a side of a triangle: ");
            double triangleSideA = Double.Parse(Console.ReadLine());
            Console.Write("Enter an integer for the length of the 2nd side: ");
            double triangleSideB = Double.Parse(Console.ReadLine());
            Console.Write("Enter an integer for the length of the 3rd side: ");
            double triangleSideC = Double.Parse(Console.ReadLine());
            double triangleP = (triangleSideA + triangleSideB + triangleSideC) / 2;
            double triangleArea = Math.Sqrt(triangleP * (triangleP - triangleSideA) * (triangleP - triangleSideB) * (triangleP - triangleSideC));
            Console.WriteLine($"The area of a triangle is {triangleArea}");
            Console.WriteLine("Press enter to continue.");
            Console.ReadLine();

            
            //Solving a quadratic equation

            Console.Write("Enter an integer for 'A' of the quadratic formula: ");
            double quadA = Int32.Parse(Console.ReadLine());
            Console.Write("Enter an integer for  'B' of the quadratic formula: ");
            double quadB = Int32.Parse(Console.ReadLine());
            Console.Write("Enter an integer for 'C' of the quadratic formula: ");
            double quadC = Int32.Parse(Console.ReadLine());
            double denominator = (2 * quadA);
            double quadXpos = (-quadB + Math.Sqrt((quadB * quadB) - (4 * quadA * quadC))) / (denominator);
            double quadXneg = (-quadB - Math.Sqrt((quadB * quadB) - (4 * quadA * quadC))) / (denominator);
            Console.WriteLine($"The positive answer for x = {quadXpos}");
            Console.WriteLine($"The negative answer for x = {quadXneg}");
            Console.ReadLine();

        }  
    }
}
